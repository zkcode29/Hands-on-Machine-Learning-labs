import socket
import threading
import sys

HOST = "127.0.0.1"
PORT = 5050   # use a safe, high port

server_running = True
client_threads = []
clients = []


def handle_client(conn, addr):
    print(f"[NEW CONNECTION] {addr} connected.")
    clients.append(conn)
    try:
        while server_running:
            data = conn.recv(1024)
            if not data:
                break
            message = data.decode().strip()
            print(f"[{addr}] {message}")
            conn.send(f"Echo: {message}\n".encode())
    except:
        pass
    finally:
        conn.close()
        if conn in clients:
            clients.remove(conn)
        print(f"[DISCONNECTED] {addr}")


def start_server():
    global server_running
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()
    print(f"[STARTED] Server running on {HOST}:{PORT}")

    def accept_clients():
        while server_running:
            try:
                conn, addr = server.accept()
                t = threading.Thread(target=handle_client, args=(conn, addr))
                client_threads.append(t)
                t.start()
            except OSError:
                break  # server closed

    threading.Thread(target=accept_clients, daemon=True).start()

    # Console commands
    while True:
        cmd = input("")
        if cmd.strip().lower() == "exit":
            print("[SHUTDOWN] Closing server...")
            server_running = False
            server.close()
            # close clients
            for c in clients:
                c.close()
            # wait for threads
            for t in client_threads:
                t.join(timeout=1)
            print("[SHUTDOWN COMPLETE]")
            sys.exit(0)


if __name__ == "__main__":
    start_server()
