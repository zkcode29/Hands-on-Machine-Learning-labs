import threading
import time

# Function to print numbers
def print_numbers():
    for i in range(1, 6):
        print(f"[{threading.current_thread().name}] Number: {i}")
        time.sleep(1)

# Function to print letters
def print_letters():
    for letter in "ABCDE":
        print(f"[{threading.current_thread().name}] Letter: {letter}")
        time.sleep(1.5)

if __name__ == "__main__":
    # Create two threads
    t1 = threading.Thread(target=print_numbers, name="NumberThread")
    t2 = threading.Thread(target=print_letters, name="LetterThread")

    print("[MAIN] Starting threads...")
    t1.start()
    t2.start()

    # Wait for both threads to complete
    t1.join()
    t2.join()

    print("[MAIN] All threads finished.")
