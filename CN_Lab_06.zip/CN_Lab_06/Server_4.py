import socket
import threading

# Server configuration
HOST = "127.0.0.1"
PORT = 5555

# Dictionary to store connected clients {client_id: socket}
clients = {}
lock = threading.Lock()
client_id_counter = 1
server_running = True

def broadcast(message, sender_id=None):
    """Send message to all clients except the sender"""
    with lock:
        for cid, sock in list(clients.items()):
            if cid != sender_id:
                try:
                    sock.sendall(message.encode("utf-8"))
                except:
                    sock.close()
                    del clients[cid]

def handle_client(conn, addr, client_id):
    """Handle communication with a client"""
    print(f"[NEW CONNECTION] Client {client_id} connected from {addr}")
    conn.sendall(f"Welcome! You are Client {client_id}".encode("utf-8"))
    
    try:
        while True:
            msg = conn.recv(1024).decode("utf-8")
            if not msg:
                break
            if msg.lower() == "exit":
                conn.sendall("Goodbye!".encode("utf-8"))
                break
            full_msg = f"Client {client_id}: {msg}"
            print(full_msg)
            broadcast(full_msg, sender_id=client_id)
    except:
        pass
    finally:
        with lock:
            if client_id in clients:
                del clients[client_id]
        conn.close()
        print(f"[DISCONNECTED] Client {client_id} disconnected.")

def server_console():
    """Server-side console commands"""
    global server_running
    while server_running:
        cmd = input("")
        if cmd.lower() == "list":
            with lock:
                print(f"[ACTIVE CLIENTS] {len(clients)} connected")
                for cid in clients:
                    print(f" - Client {cid}")
        elif cmd.lower() == "exit":
            print("[SHUTTING DOWN] Closing server...")
            server_running = False
            with lock:
                for sock in clients.values():
                    sock.close()
                clients.clear()
            break

def start_server():
    """Start the server and accept clients"""
    global client_id_counter
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()

    print(f"[STARTED] Server listening on {HOST}:{PORT}")

    threading.Thread(target=server_console, daemon=True).start()

    while server_running:
        try:
            conn, addr = server.accept()
        except OSError:
            break

        with lock:
            client_id = client_id_counter
            client_id_counter += 1
            clients[client_id] = conn

        thread = threading.Thread(target=handle_client, args=(conn, addr, client_id))
        thread.daemon = True
        thread.start()

    server.close()

if __name__ == "__main__":
    start_server()
