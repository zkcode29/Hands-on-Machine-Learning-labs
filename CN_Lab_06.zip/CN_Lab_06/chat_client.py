import socket
import threading

HOST = "127.0.0.1"  # Server IP
PORT = 5555         # Same port as server

def receive_messages(sock):
    while True:
        try:
            msg = sock.recv(1024).decode("utf-8")
            if not msg:
                break
            print(msg)
        except:
            break

def start_client():
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client.connect((HOST, PORT))

    thread = threading.Thread(target=receive_messages, args=(client,))
    thread.daemon = True
    thread.start()

    print("Type messages (type 'exit' to leave):")
    while True:
        msg = input()
        client.sendall(msg.encode("utf-8"))
        if msg.lower() == "exit":
            break

    client.close()

if __name__ == "__main__":
    start_client()
