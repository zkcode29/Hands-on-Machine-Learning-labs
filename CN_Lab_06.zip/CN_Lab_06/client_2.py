import socket
import threading
import time

SERVER_HOST = "127.0.0.1"
SERVER_PORT = 12345

def receive_messages(sock, username):
    while True:
        try:
            msg = sock.recv(1024).decode()
            if not msg:
                break

            # Split by newline and print each message cleanly
            for line in msg.strip().split("\n"):
                if line:
                    print(f"\n[{username}] -> {line}")
        except:
            break

def client_program(username, password, mode="REGISTER"):
    try:
        client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client_socket.connect((SERVER_HOST, SERVER_PORT))
    except Exception as e:
        print(f"[{username}] ERROR: {e}")
        return

    print(client_socket.recv(1024).decode().strip())

    if mode == "REGISTER":
        client_socket.send(f"REGISTER {username} {password}".encode())
        print(f"[{username}] -> {client_socket.recv(1024).decode().strip()}")
        client_socket.send(f"LOGIN {username} {password}".encode())
        print(f"[{username}] -> {client_socket.recv(1024).decode().strip()}")
    else:
        client_socket.send(f"LOGIN {username} {password}".encode())
        print(f"[{username}] -> {client_socket.recv(1024).decode().strip()}")

    threading.Thread(target=receive_messages, args=(client_socket, username), daemon=True).start()

    # Send messages
    for i in range(1, 4):
        msg = f"MSG Hello from {username}, message {i}"
        client_socket.send(msg.encode())
        time.sleep(1)

    # Logout
    client_socket.send("LOGOUT".encode())
    print(f"[{username}] -> Logged out!")
    client_socket.close()

if __name__ == "__main__":
    usernames = ["user1", "user2", "user3", "user4", "user5"]
    threads = []
    for i, uname in enumerate(usernames):
        mode = "REGISTER" if i < len(usernames)//2 else "LOGIN"
        t = threading.Thread(target=client_program, args=(uname, "pass123", mode))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()
