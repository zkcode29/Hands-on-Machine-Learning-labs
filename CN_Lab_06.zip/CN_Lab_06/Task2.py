import threading
import time
# Shared resource
counter = 0
# Create a lock
lock = threading.Lock()

def increment_counter():
    global counter
    for _ in range(5):
        time.sleep(0.5)  # simulate some work before accessing
        with lock:  # acquire lock before modifying shared resource
            local_copy = counter
            local_copy += 1
            time.sleep(0.1)  # simulate more work
            counter = local_copy
            print(f"[{threading.current_thread().name}] Counter: {counter}")
# Execute these statements when the file is run as a program
if __name__ == "__main__":
    # Create two threads that increment the same counter
    t1 = threading.Thread(target=increment_counter, name="Thread-1")
    t2 = threading.Thread(target=increment_counter, name="Thread-2")
    print("[MAIN] Starting threads...")
    t1.start()
    t2.start()

    t1.join()
    t2.join()
    print(f"[MAIN] Final Counter Value: {counter}")
