import socket
import threading

HOST = "127.0.0.1"
PORT = 12345

users = {}       # username -> password
clients = {}     # username -> socket

def handle_client(conn, addr):
    print(f"[NEW CONNECTION] {addr} connected.")
    conn.send("Welcome! Use REGISTER or LOGIN\n".encode())

    username = None
    try:
        while True:
            data = conn.recv(1024).decode().strip()
            if not data:
                break

            parts = data.split()
            cmd = parts[0].upper()

            if cmd == "REGISTER" and len(parts) == 3:
                uname, pwd = parts[1], parts[2]
                if uname in users:
                    conn.send("Username already exists\n".encode())
                else:
                    users[uname] = pwd
                    conn.send("Registration successful!\n".encode())

            elif cmd == "LOGIN" and len(parts) == 3:
                uname, pwd = parts[1], parts[2]
                if uname in users and users[uname] == pwd:
                    clients[uname] = conn
                    username = uname
                    conn.send("Login successful!\n".encode())
                else:
                    conn.send("Invalid credentials\n".encode())

            elif cmd == "MSG" and username:
                message = " ".join(parts[1:])
                broadcast(f"[{username}] {message}\n", username)

            elif cmd == "LOGOUT" and username:
                conn.send("Logged out!\n".encode())
                del clients[username]
                break

            else:
                conn.send("Invalid command\n".encode())
    except:
        pass
    finally:
        if username and username in clients:
            del clients[username]
        conn.close()


def broadcast(message, sender=None):
    for uname, client in clients.items():
        if uname != sender:
            try:
                client.send(message.encode())
            except:
                pass


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen()
    print(f"[STARTED] Server running on {HOST}:{PORT}")

    while True:
        conn, addr = server.accept()
        thread = threading.Thread(target=handle_client, args=(conn, addr))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.active_count() - 1}")


if __name__ == "__main__":
    start_server()
