import socket

HOST = "127.0.0.1"
PORT = 5050

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))
print("Connected to server. Type messages...")

try:
    while True:
        msg = input("You: ")
        if msg.lower() == "quit":
            break
        client.send(msg.encode())
        response = client.recv(1024).decode()
        print("Server:", response.strip())
finally:
    client.close()
