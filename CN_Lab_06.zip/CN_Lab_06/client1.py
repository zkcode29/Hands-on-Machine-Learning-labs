import socket

HOST = "127.0.0.1"
PORT = 5000

# Create a socket and connect to the server
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

print("Connected to server. Type messages... (type 'quit' to exit)")

while True:
    msg = input("You: ")
    if msg.lower() == "quit":
        break

    # Send message to server
    client.send(msg.encode("utf-8"))

    # Receive server response
    response = client.recv(1024).decode("utf-8")
    print(f"Server: {response}")

# Close the connection
client.close()
