import socket
import threading

HOST = "127.0.0.1"  # Localhost
PORT = 5555         # Change port if needed

clients = {}  # {client_socket: client_id}
lock = threading.Lock()
client_id_counter = 1

def broadcast(message, sender_socket=None):
    """Send message to all clients except the sender."""
    with lock:
        for client in clients:
            if client != sender_socket:  
                try:
                    client.sendall(message.encode("utf-8"))
                except:
                    client.close()
                    del clients[client]

def handle_client(conn, addr, client_id):
    print(f"[NEW CONNECTION] Client {client_id} connected from {addr}")
    conn.sendall(f"Welcome! You are Client {client_id}".encode("utf-8"))
    try:
        while True:
            msg = conn.recv(1024).decode("utf-8")
            if not msg:
                break
            if msg.lower() == "exit":
                conn.sendall("Goodbye!".encode("utf-8"))
                break
            full_msg = f"Client {client_id}: {msg}"
            print(full_msg)
            broadcast(full_msg, sender_socket=conn)
    except:
        pass
    finally:
        with lock:
            del clients[conn]
        conn.close()
        print(f"[DISCONNECTED] Client {client_id} disconnected.")

def start_server():
    global client_id_counter
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen()

    print(f"[STARTED] Server is listening on {HOST}:{PORT}")

    while True:
        conn, addr = server.accept()
        with lock:
            client_id = client_id_counter
            client_id_counter += 1
            clients[conn] = client_id
        thread = threading.Thread(target=handle_client, args=(conn, addr, client_id))
        thread.start()

if __name__ == "__main__":
    start_server()
