import socket
import threading

# Define server host and port
HOST = "127.0.0.1"  # localhost
PORT = 5000         # non-privileged port

# Function to handle client connections
def handle_client(client_socket, client_address):
    print(f"[NEW CONNECTION] {client_address} connected.")
    try:
        while True:
            # Receive message from client
            message = client_socket.recv(1024).decode("utf-8")
            if not message:
                break  # client disconnected
            print(f"[{client_address}] {message}")

            # Send response back to client
            response = f"Echo: {message}"
            client_socket.send(response.encode("utf-8"))
    except ConnectionResetError:
        print(f"[ERROR] Connection reset by {client_address}")
    finally:
        client_socket.close()
        print(f"[DISCONNECTED] {client_address} closed.")

# Main server loop
def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((HOST, PORT))
    server.listen(5)  # max queued connections
    print(f"[LISTENING] Server is listening on {HOST}:{PORT}")

    while True:
        client_socket, client_address = server.accept()
        # Start a new thread for each client
        thread = threading.Thread(target=handle_client, args=(client_socket, client_address))
        thread.start()
        print(f"[ACTIVE CONNECTIONS] {threading.active_count() - 1}")

if __name__ == "__main__":
    print("[STARTING] Server is starting...")
    start_server()
